package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Sigorta {
    public int id;
    public int hastaId;
    public String saglayici;
    public String policeNumarasi;
    public String kapsamDetaylari;
    public double kapsamYuzdesi;

    private static final String DB_URL = "jdbc:sqlite:hospital.db";

    // Constructor
    public Sigorta(int id, int hastaId, String saglayici, String poliçeNumarasi, String kapsamDetaylari,
            double kapsamYuzdesi) {
        this.id = id;
        this.hastaId = hastaId;
        this.saglayici = saglayici;
        this.policeNumarasi = poliçeNumarasi;
        this.kapsamDetaylari = kapsamDetaylari;
        this.kapsamYuzdesi = kapsamYuzdesi;
    }

    public Sigorta() {
    }

    // Fetch insurance details by patient ID
    public static List<Sigorta> fetchSigortaByPatientId(int hastaId) {
        List<Sigorta> sigortaList = new ArrayList<>();
        String query = "SELECT * FROM Insurance WHERE patient_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, hastaId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Sigorta sigorta = new Sigorta(
                        rs.getInt("id"),
                        rs.getInt("patient_id"),
                        rs.getString("provider"),
                        rs.getString("policy_number"),
                        rs.getString("coverage_details"),
                        rs.getDouble("coverage_percentage"));
                sigortaList.add(sigorta);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sigortaList;
    }

    // Add new insurance policy
    public static boolean addSigorta(int hastaId, String saglayici, String poliçeNumarasi, String kapsamDetaylari,
            double kapsamYuzdesi) {
        String query = "INSERT INTO Insurance (patient_id, provider, policy_number, coverage_details, coverage_percentage) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, hastaId);
            pstmt.setString(2, saglayici);
            pstmt.setString(3, poliçeNumarasi);
            pstmt.setString(4, kapsamDetaylari);
            pstmt.setDouble(5, kapsamYuzdesi);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Update insurance details
    public static boolean updateSigorta(int hastaId, String saglayici, String poliçeNumarasi, String kapsamDetaylari,
            double kapsamYuzdesi) {
        String query = "UPDATE Insurance SET provider = ?, policy_number = ?, coverage_details = ?, coverage_percentage = ? WHERE patient_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, saglayici);
            pstmt.setString(2, poliçeNumarasi);
            pstmt.setString(3, kapsamDetaylari);
            pstmt.setDouble(4, kapsamYuzdesi);
            pstmt.setInt(5, hastaId);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete insurance record by patient ID
    public static boolean deleteSigorta(int hastaId) {
        String query = "DELETE FROM Insurance WHERE patient_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, hastaId);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Fetch all insurance records
    public static List<Sigorta> fetchAllSigortalar() {
        List<Sigorta> sigortaList = new ArrayList<>();
        String query = "SELECT * FROM Insurance";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query);
                ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Sigorta sigorta = new Sigorta(
                        rs.getInt("id"),
                        rs.getInt("patient_id"),
                        rs.getString("provider"),
                        rs.getString("policy_number"),
                        rs.getString("coverage_details"),
                        rs.getDouble("coverage_percentage"));
                sigortaList.add(sigorta);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sigortaList;
    }
}
