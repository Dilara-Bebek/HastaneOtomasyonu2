package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Personel {
    public int id;
    public String ad;
    public String soyad;
    public String rol;
    public String kimlikNo;

    public static List<Personel> fetchAllPersonnel() {
        List<Personel> personelListesi = new ArrayList<>();
        String query = "SELECT * FROM Staff";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query);
                ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Personel personel = new Personel();
                personel.id = rs.getInt("id");
                personel.ad = rs.getString("name");
                personel.soyad = rs.getString("surname");
                personel.rol = rs.getString("role");
                personel.kimlikNo = rs.getString("identity_number");
                personelListesi.add(personel);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return personelListesi;
    }

    public static Personel fetchPersonnelById(int personelId) {
        Personel personel = null;
        String query = "SELECT * FROM Staff WHERE id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, personelId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                personel = new Personel();
                personel.id = rs.getInt("id");
                personel.ad = rs.getString("name");
                personel.soyad = rs.getString("surname");
                personel.rol = rs.getString("role");
                personel.kimlikNo = rs.getString("identity_number");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return personel;
    }

    public static boolean addPersonnel(String ad, String soyad, String rol, String kimlikNo) {
        String query = "INSERT INTO Staff (name, surname, role, identity_number) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, ad);
            pstmt.setString(2, soyad);
            pstmt.setString(3, rol);
            pstmt.setString(4, kimlikNo);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean updatePersonnel(int id, String ad, String soyad, String rol, String kimlikNo) {
        String query = "UPDATE Staff SET name = ?, surname = ?, role = ?, identity_number = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, ad);
            pstmt.setString(2, soyad);
            pstmt.setString(3, rol);
            pstmt.setString(4, kimlikNo);
            pstmt.setInt(5, id);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean deletePersonnel(int id) {
        String query = "DELETE FROM Staff WHERE id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, id);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
