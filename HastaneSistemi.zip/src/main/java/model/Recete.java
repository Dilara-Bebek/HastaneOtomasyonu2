package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Recete {
    public int id;
    public int hastaId;
    public int doktorId;
    public String ilacAdi;
    public String dozaj;
    public double maliyet;

    private static final String DB_URL = "jdbc:sqlite:hospital.db";

    public Recete(int id, int hastaId, int doktorId, String ilacAdi, String dozaj, double maliyet) {
        this.id = id;
        this.hastaId = hastaId;
        this.doktorId = doktorId;
        this.ilacAdi = ilacAdi;
        this.dozaj = dozaj;
        this.maliyet = maliyet;
    }

    public static boolean addRecete(int hastaId, int doktorId, String ilacAdi, String dozaj, double maliyet) {
        String query = "INSERT INTO Prescription (patient_id, doctor_id, medication_name, dosage, cost) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, hastaId);
            pstmt.setInt(2, doktorId);
            pstmt.setString(3, ilacAdi);
            pstmt.setString(4, dozaj);
            pstmt.setDouble(5, maliyet);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<Recete> fetchReceteByDoctorId(int doktorId) {
        List<Recete> receteList = new ArrayList<>();
        String query = "SELECT * FROM Prescription WHERE doctor_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, doktorId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Recete recete = new Recete(
                        rs.getInt("id"),
                        rs.getInt("patient_id"),
                        rs.getInt("doctor_id"),
                        rs.getString("medication_name"),
                        rs.getString("dosage"),
                        rs.getDouble("cost"));
                receteList.add(recete);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return receteList;
    }
}
