package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Tedavi {
    public int id;
    public int hastaId;
    public int doktorId;
    public Hasta hasta;
    public Doktor doktor;
    public String tedaviAdi;
    public String aciklama;
    public String baslangicTarihi;
    public String bitisTarihi;
    public double maliyet;

    public static List<Tedavi> fetchTreatmentsByPatientId(int hastaId) {
        List<Tedavi> tedaviListesi = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Treatment WHERE patient_id = ?")) {
            pstmt.setInt(1, hastaId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Tedavi tedavi = new Tedavi();
                tedavi.id = rs.getInt("id");
                tedavi.hastaId = rs.getInt("patient_id");
                tedavi.doktorId = rs.getInt("doctor_id");
                tedavi.tedaviAdi = rs.getString("treatment_name");
                tedavi.aciklama = rs.getString("description");
                tedavi.baslangicTarihi = rs.getString("start_date");
                tedavi.bitisTarihi = rs.getString("end_date");
                tedavi.maliyet = rs.getDouble("cost");
                tedavi.hasta = Hasta.getHastaFromID(tedavi.hastaId);
                tedavi.doktor = Doktor.fetchDoktorById(tedavi.doktorId);
                tedaviListesi.add(tedavi);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tedaviListesi;
    }

    public static List<Tedavi> fetchTreatmentsByDoctorId(int doktorId) {
        List<Tedavi> tedaviListesi = new ArrayList<>();
        String query = "SELECT * FROM Treatment WHERE doctor_id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, doktorId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Tedavi tedavi = new Tedavi();
                tedavi.id = rs.getInt("id");
                tedavi.hastaId = rs.getInt("patient_id");
                tedavi.doktorId = rs.getInt("doctor_id");
                tedavi.tedaviAdi = rs.getString("treatment_name");
                tedavi.aciklama = rs.getString("description");
                tedavi.baslangicTarihi = rs.getString("start_date");
                tedavi.bitisTarihi = rs.getString("end_date");
                tedavi.maliyet = rs.getDouble("cost");
                tedavi.hasta = Hasta.getHastaFromID(tedavi.hastaId);
                tedavi.doktor = Doktor.fetchDoktorById(tedavi.doktorId);
                tedaviListesi.add(tedavi);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tedaviListesi;
    }

    public static boolean addTreatment(int hastaId, int doktorId, String tedaviAdi, String aciklama,
            String baslangicTarihi, String bitisTarihi, double maliyet) {
        String query = "INSERT INTO Treatment (patient_id, doctor_id, treatment_name, description, start_date, end_date, cost) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, hastaId);
            pstmt.setInt(2, doktorId);
            pstmt.setString(3, tedaviAdi);
            pstmt.setString(4, aciklama);
            pstmt.setString(5, baslangicTarihi);
            pstmt.setString(6, bitisTarihi);
            pstmt.setDouble(7, maliyet);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean deleteTedavi(int tedaviId) {
        String query = "DELETE FROM Treatment WHERE id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, tedaviId);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

}
