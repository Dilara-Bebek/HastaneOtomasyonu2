package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Admin {
    public int id;
    public String ad;
    public String soyad;
    public String kullaniciAdi;

    public static Admin fetchAdministratorById(int adminId) {
        Admin admin = new Admin();
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Administrator WHERE id = ?")) {
            pstmt.setInt(1, adminId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                admin.id = rs.getInt("id");
                admin.ad = rs.getString("name");
                admin.soyad = rs.getString("surname");
                admin.kullaniciAdi = rs.getString("username");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return admin;
    }
}
