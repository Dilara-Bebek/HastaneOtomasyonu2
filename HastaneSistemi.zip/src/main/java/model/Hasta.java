package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Hasta {
    public int id;
    public String ad;
    public String soyad;
    public int yas;
    public String kimlikNo;
    public String adres;
    public List<String> medikalGecmis;

    // Fetch patient by ID
    public static Hasta getHastaFromID(int hastaId) {
        Hasta hasta = null;
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Patient WHERE id = ?")) {
            pstmt.setInt(1, hastaId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                hasta = new Hasta();
                hasta.id = rs.getInt("id");
                hasta.ad = rs.getString("name");
                hasta.soyad = rs.getString("surname");
                hasta.yas = rs.getInt("age");
                hasta.kimlikNo = rs.getString("identity_number");
                hasta.adres = rs.getString("address");
                hasta.medikalGecmis = fetchMedicalHistory(hastaId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hasta;
    }

    // Fetch medical history for a patient
    private static List<String> fetchMedicalHistory(int hastaId) {
        List<String> medikalGecmis = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn
                        .prepareStatement("SELECT description FROM MedicalHistory WHERE patient_id = ?")) {
            pstmt.setInt(1, hastaId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                medikalGecmis.add(rs.getString("description"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return medikalGecmis;
    }

    // Fetch all patients
    public static List<Hasta> fetchAllPatients() {
        List<Hasta> hastaListesi = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Patient")) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Hasta hasta = new Hasta();
                hasta.id = rs.getInt("id");
                hasta.ad = rs.getString("name");
                hasta.soyad = rs.getString("surname");
                hasta.yas = rs.getInt("age");
                hasta.kimlikNo = rs.getString("identity_number");
                hasta.adres = rs.getString("address");
                hasta.medikalGecmis = fetchMedicalHistory(hasta.id);
                hastaListesi.add(hasta);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hastaListesi;
    }

    // Add a new patient
    public static boolean addPatient(String ad, String soyad, int yas, String kimlikNo, String adres) {
        String query = "INSERT INTO Patient (name, surname, age, identity_number, address) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, ad);
            pstmt.setString(2, soyad);
            pstmt.setInt(3, yas);
            pstmt.setString(4, kimlikNo);
            pstmt.setString(5, adres);
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Update patient information
    public static boolean updatePatient(int hastaId, String ad, String soyad, int yas, String kimlikNo, String adres) {
        String query = "UPDATE Patient SET name = ?, surname = ?, age = ?, identity_number = ?, address = ? WHERE id = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, ad);
            pstmt.setString(2, soyad);
            pstmt.setInt(3, yas);
            pstmt.setString(4, kimlikNo);
            pstmt.setString(5, adres);
            pstmt.setInt(6, hastaId);
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete a patient by ID
    public static boolean deletePatient(int hastaId) {
        String query = "DELETE FROM Patient WHERE id = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, hastaId);
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
