package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LaboratuvarSonucu {
    public int id;
    public int hastaId;
    public int doktorId;
    public Hasta hasta;
    public Doktor doktor;
    public String testAdi;
    public String sonuc;
    public String testTarihi;

    private static final String DB_URL = "jdbc:sqlite:hospital.db";

    public LaboratuvarSonucu(int id, int hastaId, int doktorId, String testAdi, String sonuc, String testTarihi) {
        this.id = id;
        this.hastaId = hastaId;
        this.doktorId = doktorId;
        this.testAdi = testAdi;
        this.sonuc = sonuc;
        this.testTarihi = testTarihi;
    }

    // Fetch lab results by patient ID
    public static List<LaboratuvarSonucu> fetchLaboratuvarSonucuByPatientId(int hastaId) {
        List<LaboratuvarSonucu> resultsList = new ArrayList<>();
        String query = "SELECT * FROM LaboratoryResults WHERE patient_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, hastaId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                LaboratuvarSonucu result = new LaboratuvarSonucu(
                        rs.getInt("id"),
                        rs.getInt("patient_id"),
                        rs.getInt("doctor_id"),
                        rs.getString("test_type"),
                        rs.getString("result"),
                        rs.getString("date"));
                result.doktor = Doktor.fetchDoktorById(result.doktorId);
                result.hasta = Hasta.getHastaFromID(result.hastaId);
                resultsList.add(result);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultsList;
    }

    // Add new laboratory result
    public static boolean addLabResult(int hastaId, int doktorId, String testAdi, String sonuc, String testTarihi) {
        String query = "INSERT INTO LaboratoryResults (patient_id, doctor_id, test_type, result, date) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, hastaId);
            pstmt.setInt(2, doktorId);
            pstmt.setString(3, testAdi);
            pstmt.setString(4, sonuc);
            pstmt.setString(5, testTarihi);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Update lab result
    public static boolean updateLabResult(int id, String testAdi, String sonuc) {
        String query = "UPDATE LaboratoryResults SET test_type = ?, result = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, testAdi);
            pstmt.setString(2, sonuc);
            pstmt.setInt(3, id);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete lab result
    public static boolean deleteLabResult(int id) {
        String query = "DELETE FROM LaboratoryResults WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, id);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Fetch all lab results
    public static List<LaboratuvarSonucu> fetchAllResults() {
        List<LaboratuvarSonucu> resultsList = new ArrayList<>();
        String query = "SELECT * FROM LaboratoryResults";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query);
                ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                LaboratuvarSonucu result = new LaboratuvarSonucu(
                        rs.getInt("id"),
                        rs.getInt("patient_id"),
                        rs.getInt("doctor_id"),
                        rs.getString("test_type"),
                        rs.getString("result"),
                        rs.getString("date"));
                resultsList.add(result);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultsList;
    }

    // Fetch lab results by doctor ID
    public static List<LaboratuvarSonucu> fetchLaboratuvarSonucuByDoctorId(int doktorId) {
        List<LaboratuvarSonucu> resultsList = new ArrayList<>();
        String query = "SELECT * FROM LaboratoryResults WHERE doctor_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, doktorId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                LaboratuvarSonucu result = new LaboratuvarSonucu(
                        rs.getInt("id"),
                        rs.getInt("patient_id"),
                        rs.getInt("doctor_id"),
                        rs.getString("test_type"),
                        rs.getString("result"),
                        rs.getString("date"));
                resultsList.add(result);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultsList;
    }
}
