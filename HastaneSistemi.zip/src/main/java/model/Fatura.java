package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Fatura {
    public int id;
    public int hastaId;
    public double toplamTutar;
    public String odemeDurumu;
    public String faturaDetaylari;
    public String tarih;

    private static final String DB_URL = "jdbc:sqlite:hospital.db";

    // Constructor
    public Fatura(int id, int hastaId, double toplamTutar, String odemeDurumu, String faturaDetaylari, String tarih) {
        this.id = id;
        this.hastaId = hastaId;
        this.toplamTutar = toplamTutar;
        this.odemeDurumu = odemeDurumu;
        this.faturaDetaylari = faturaDetaylari;
        this.tarih = tarih;
    }

    public Fatura() {
    }

    // Fetch bill details by patient ID
    public static List<Fatura> fetchFaturalarByPatientId(int hastaId) {
        List<Fatura> faturaList = new ArrayList<>();
        String query = "SELECT * FROM Billing WHERE patient_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, hastaId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Fatura fatura = new Fatura(
                        rs.getInt("id"),
                        rs.getInt("patient_id"),
                        rs.getDouble("total_amount"),
                        rs.getString("payment_status"),
                        rs.getString("bill_details"),
                        rs.getString("date"));
                faturaList.add(fatura);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return faturaList;
    }

    // Add new bill
    public static boolean addFatura(int hastaId, double toplamTutar, String odemeDurumu, String faturaDetaylari,
            String tarih) {
        String query = "INSERT INTO Billing (patient_id, total_amount, payment_status, bill_details, date) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, hastaId);
            pstmt.setDouble(2, toplamTutar);
            pstmt.setString(3, odemeDurumu);
            pstmt.setString(4, faturaDetaylari);
            pstmt.setString(5, tarih);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Update bill details
    public static boolean updateFatura(int faturaId, double toplamTutar, String odemeDurumu, String faturaDetaylari) {
        String query = "UPDATE Billing SET total_amount = ?, payment_status = ?, bill_details = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setDouble(1, toplamTutar);
            pstmt.setString(2, odemeDurumu);
            pstmt.setString(3, faturaDetaylari);
            pstmt.setInt(4, faturaId);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete bill by ID
    public static boolean deleteFatura(int faturaId) {
        String query = "DELETE FROM Billing WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, faturaId);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Fetch all bills
    public static List<Fatura> fetchAllFaturalar() {
        List<Fatura> faturaList = new ArrayList<>();
        String query = "SELECT * FROM Billing";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query);
                ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Fatura fatura = new Fatura(
                        rs.getInt("id"),
                        rs.getInt("patient_id"),
                        rs.getDouble("total_amount"),
                        rs.getString("payment_status"),
                        rs.getString("bill_details"),
                        rs.getString("date"));
                faturaList.add(fatura);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return faturaList;
    }
}
