package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Randevu {
    public int id;
    public int hastaId;
    public int doktorId;
    public String tarih;
    public String zaman;
    public Hasta hasta;
    public Doktor doktor;

    public static List<Randevu> fetchAppointmentsByPatientId(int hastaId) {
        List<Randevu> randevuListesi = new ArrayList<>();
        String query = "SELECT a.id, a.date, a.time, a.patient_id, a.doctor_id " +
                "FROM Appointment a " +
                "WHERE a.patient_id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, hastaId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Randevu randevu = new Randevu();
                randevu.id = rs.getInt("id");
                randevu.hastaId = rs.getInt("patient_id");
                randevu.doktorId = rs.getInt("doctor_id");
                randevu.tarih = rs.getString("date");
                randevu.zaman = rs.getString("time");

                // Fetching Hasta and Doktor objects by their IDs
                randevu.hasta = Hasta.getHastaFromID(randevu.hastaId);
                randevu.doktor = Doktor.fetchDoktorById(randevu.doktorId);

                randevuListesi.add(randevu);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return randevuListesi;
    }

    public static List<Randevu> fetchAppointmentsByDoctorId(int doktorId) {
        List<Randevu> randevuListesi = new ArrayList<>();
        String query = "SELECT a.id, a.date, a.time, a.patient_id, a.doctor_id " +
                "FROM Appointment a " +
                "WHERE a.doctor_id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, doktorId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Randevu randevu = new Randevu();
                randevu.id = rs.getInt("id");
                randevu.hastaId = rs.getInt("patient_id");
                randevu.doktorId = rs.getInt("doctor_id");
                randevu.tarih = rs.getString("date");
                randevu.zaman = rs.getString("time");

                // Fetching Hasta and Doktor objects by their IDs
                randevu.hasta = Hasta.getHastaFromID(randevu.hastaId);
                randevu.doktor = Doktor.fetchDoktorById(randevu.doktorId);

                randevuListesi.add(randevu);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return randevuListesi;
    }

    public static boolean addAppointment(int hastaId, int doktorId, String tarih, String saat) {
        String insertQuery = "INSERT INTO Appointment (patient_id, doctor_id, date, time) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {
            pstmt.setInt(1, hastaId);
            pstmt.setInt(2, doktorId);
            pstmt.setString(3, tarih);
            pstmt.setString(4, saat);
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean deleteAppointment(int randevuId) {
        String query = "DELETE FROM Appointment WHERE id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, randevuId);
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
