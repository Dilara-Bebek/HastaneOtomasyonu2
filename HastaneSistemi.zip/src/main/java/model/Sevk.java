package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Sevk {
    public int id;
    public int hastaId;
    public Hasta hasta;
    public String sevkTarihi;
    public String hedefHastane;
    public String sevkNedeni;
    public String sevkEdenDoktor;
    public String aciklama;

    private static final String DB_URL = "jdbc:sqlite:hospital.db";

    public Sevk(int id, int hastaId, String sevkTarihi, String hedefHastane, String sevkNedeni, String sevkEdenDoktor,
            String aciklama) {
        this.id = id;
        this.hastaId = hastaId;
        this.sevkTarihi = sevkTarihi;
        this.hedefHastane = hedefHastane;
        this.sevkNedeni = sevkNedeni;
        this.sevkEdenDoktor = sevkEdenDoktor;
        this.aciklama = aciklama;
        this.hasta = Hasta.getHastaFromID(hastaId);
    }

    public static List<Sevk> fetchReferralsByPatientId(int hastaId) {
        List<Sevk> sevkList = new ArrayList<>();
        String query = "SELECT * FROM Referral WHERE patient_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, hastaId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Sevk sevk = new Sevk(
                        rs.getInt("id"),
                        rs.getInt("patient_id"),
                        rs.getString("referral_date"),
                        rs.getString("destination_hospital"),
                        rs.getString("reason"),
                        rs.getString("referring_doctor"),
                        rs.getString("description"));
                sevkList.add(sevk);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sevkList;
    }

    public static boolean addReferral(int hastaId, String sevkTarihi, String hedefHastane, String sevkNedeni,
            String sevkEdenDoktor, String aciklama) {
        String query = "INSERT INTO Referral (patient_id, referral_date, destination_hospital, reason, referring_doctor, description) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, hastaId);
            pstmt.setString(2, sevkTarihi);
            pstmt.setString(3, hedefHastane);
            pstmt.setString(4, sevkNedeni);
            pstmt.setString(5, sevkEdenDoktor);
            pstmt.setString(6, aciklama);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean updateReferral(int id, String hedefHastane, String sevkNedeni, String aciklama) {
        String query = "UPDATE Referral SET destination_hospital = ?, reason = ?, description = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, hedefHastane);
            pstmt.setString(2, sevkNedeni);
            pstmt.setString(3, aciklama);
            pstmt.setInt(4, id);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean deleteReferral(int id) {
        String query = "DELETE FROM Referral WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, id);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<Sevk> fetchAllReferrals() {
        List<Sevk> sevkList = new ArrayList<>();
        String query = "SELECT * FROM Referral";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement pstmt = conn.prepareStatement(query);
                ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Sevk sevk = new Sevk(
                        rs.getInt("id"),
                        rs.getInt("patient_id"),
                        rs.getString("referral_date"),
                        rs.getString("destination_hospital"),
                        rs.getString("reason"),
                        rs.getString("referring_doctor"),
                        rs.getString("description"));
                sevkList.add(sevk);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sevkList;
    }
}
