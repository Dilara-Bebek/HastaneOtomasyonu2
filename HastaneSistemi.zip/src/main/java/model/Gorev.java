package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Gorev {
    public int id;
    public int staffId;
    public Personel personel;
    public String description;
    public String dueDate;
    public String status;

    public Gorev() {
    }

    public Gorev(int staffId, String description, String dueDate, String status) {
        this.staffId = staffId;
        this.description = description;
        this.dueDate = dueDate;
        this.status = status;
    }

    public static List<Gorev> fetchTasksByStaffId(int staffId) {
        List<Gorev> taskList = new ArrayList<>();
        String query = "SELECT * FROM Task WHERE staff_id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, staffId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Gorev task = new Gorev();
                task.id = rs.getInt("id");
                task.staffId = rs.getInt("staff_id");
                task.description = rs.getString("description");
                task.dueDate = rs.getString("due_date");
                task.status = rs.getString("status");
                task.personel = Personel.fetchPersonnelById(task.staffId);
                taskList.add(task);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return taskList;
    }

    public static boolean addTask(int staffId, String description, String dueDate, String status) {
        String query = "INSERT INTO Task (staff_id, description, due_date, status) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, staffId);
            pstmt.setString(2, description);
            pstmt.setString(3, dueDate);
            pstmt.setString(4, status);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean updateTask(int id, String description, String dueDate, String status) {
        String query = "UPDATE Task SET description = ?, due_date = ?, status = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, description);
            pstmt.setString(2, dueDate);
            pstmt.setString(3, status);
            pstmt.setInt(4, id);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean deleteTask(int id) {
        String query = "DELETE FROM Task WHERE id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, id);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<Gorev> getAllTasks() {
        List<Gorev> taskList = new ArrayList<>();
        String query = "SELECT * FROM Task";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Gorev task = new Gorev();
                task.id = rs.getInt("id");
                task.staffId = rs.getInt("staff_id");
                task.description = rs.getString("description");
                task.dueDate = rs.getString("due_date");
                task.status = rs.getString("status");
                task.personel = Personel.fetchPersonnelById(task.staffId);
                taskList.add(task);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return taskList;
    }
}
