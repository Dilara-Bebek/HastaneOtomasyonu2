package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Doktor {
    public int id;
    public String ad;
    public String soyad;
    public String uzmanlik;
    public String calismaSaatleri;
    public String kimlikNumarasi;

    public static Doktor fetchDoktorById(int doktorId) {
        Doktor doktor = null;
        String query = "SELECT * FROM Doctor WHERE id = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, doktorId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                doktor = new Doktor();
                doktor.id = rs.getInt("id");
                doktor.ad = rs.getString("name");
                doktor.soyad = rs.getString("surname");
                doktor.uzmanlik = rs.getString("specialty");
                doktor.calismaSaatleri = rs.getString("work_hours");
                doktor.kimlikNumarasi = rs.getString("identity_number");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return doktor;
    }

    public static List<Doktor> fetchAllDoctors() {
        List<Doktor> doktorList = new ArrayList<>();
        String query = "SELECT * FROM Doctor";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query);
                ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                Doktor doktor = new Doktor();
                doktor.id = rs.getInt("id");
                doktor.ad = rs.getString("name");
                doktor.soyad = rs.getString("surname");
                doktor.uzmanlik = rs.getString("specialty");
                doktor.calismaSaatleri = rs.getString("work_hours");
                doktor.kimlikNumarasi = rs.getString("identity_number");
                doktorList.add(doktor);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return doktorList;
    }

    public static boolean addDoctor(String ad, String soyad, String uzmanlik, String calismaSaatleri,
            String kimlikNumarasi) {
        String query = "INSERT INTO Doctor (name, surname, specialty, work_hours, identity_number) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, ad);
            pstmt.setString(2, soyad);
            pstmt.setString(3, uzmanlik);
            pstmt.setString(4, calismaSaatleri);
            pstmt.setString(5, kimlikNumarasi);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean updateDoctor(int id, String ad, String soyad, String uzmanlik, String calismaSaatleri,
            String kimlikNumarasi) {
        String query = "UPDATE Doctor SET name = ?, surname = ?, specialty = ?, work_hours = ?, identity_number = ? WHERE id = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, ad);
            pstmt.setString(2, soyad);
            pstmt.setString(3, uzmanlik);
            pstmt.setString(4, calismaSaatleri);
            pstmt.setString(5, kimlikNumarasi);
            pstmt.setInt(6, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean deleteDoctor(int id) {
        String query = "DELETE FROM Doctor WHERE id = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean isDoctorAvailable(int doctorId, String tarih, String saat) {
        String query = "SELECT COUNT(*) FROM Appointment WHERE doctor_id = ? AND date = ? AND time = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:hospital.db");
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, doctorId);
            pstmt.setString(2, tarih);
            pstmt.setString(3, saat);
            ResultSet rs = pstmt.executeQuery();
            return rs.next() && rs.getInt(1) == 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
