import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {
    private static final String URL = "jdbc:sqlite:hospital.db";

    public static void tableOlustur() {
        try (Connection conn = DriverManager.getConnection(URL);
                Statement stmt = conn.createStatement()) {

            String patientTable = "CREATE TABLE IF NOT EXISTS Patient ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "name TEXT NOT NULL,"
                    + "surname TEXT NOT NULL,"
                    + "age INTEGER NOT NULL,"
                    + "identity_number TEXT UNIQUE NOT NULL,"
                    + "address TEXT,"
                    + "password TEXT NOT NULL"
                    + ");";

            String medicalHistoryTable = "CREATE TABLE IF NOT EXISTS MedicalHistory ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "patient_id INTEGER NOT NULL,"
                    + "description TEXT NOT NULL,"
                    + "date TEXT NOT NULL,"
                    + "FOREIGN KEY (patient_id) REFERENCES Patient(id)"
                    + ");";

            String doctorTable = "CREATE TABLE IF NOT EXISTS Doctor ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "name TEXT NOT NULL,"
                    + "surname TEXT NOT NULL,"
                    + "specialty TEXT NOT NULL,"
                    + "work_hours TEXT,"
                    + "identity_number TEXT UNIQUE NOT NULL,"
                    + "password TEXT NOT NULL"
                    + ");";

            String appointmentTable = "CREATE TABLE IF NOT EXISTS Appointment ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "patient_id INTEGER,"
                    + "doctor_id INTEGER,"
                    + "date TEXT NOT NULL,"
                    + "time TEXT NOT NULL,"
                    + "FOREIGN KEY (patient_id) REFERENCES Patient(id),"
                    + "FOREIGN KEY (doctor_id) REFERENCES Doctor(id)"
                    + ");";

            String treatmentTable = """
                    CREATE TABLE IF NOT EXISTS Treatment (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        patient_id INTEGER,
                        doctor_id INTEGER,
                        treatment_name TEXT NOT NULL,
                        description TEXT,
                        start_date TEXT,
                        end_date TEXT,
                        cost REAL NOT NULL,
                        FOREIGN KEY (patient_id) REFERENCES Patient(id),
                        FOREIGN KEY (doctor_id) REFERENCES Doctor(id)
                    );""";

            String medicationTable = """
                    CREATE TABLE IF NOT EXISTS Medication (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        medication_name TEXT NOT NULL,
                        stock INTEGER,
                        cost REAL NOT NULL
                    );""";

            String staffTable = "CREATE TABLE IF NOT EXISTS Staff ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "name TEXT NOT NULL,"
                    + "surname TEXT NOT NULL,"
                    + "role TEXT NOT NULL,"
                    + "identity_number TEXT UNIQUE NOT NULL"
                    + ");";

            String adminTable = "CREATE TABLE IF NOT EXISTS Administrator ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "name TEXT NOT NULL,"
                    + "surname TEXT NOT NULL,"
                    + "username TEXT UNIQUE NOT NULL,"
                    + "password TEXT NOT NULL"
                    + ");";

            String prescriptionTable = """
                    CREATE TABLE IF NOT EXISTS Prescription (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        patient_id INTEGER,
                        doctor_id INTEGER,
                        medication_name TEXT NOT NULL,
                        dosage TEXT NOT NULL,
                        cost REAL NOT NULL,
                        FOREIGN KEY (patient_id) REFERENCES Patient(id),
                        FOREIGN KEY (doctor_id) REFERENCES Doctor(id)
                    );""";

            String taskTable = "CREATE TABLE IF NOT EXISTS Task ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "staff_id INTEGER,"
                    + "description TEXT NOT NULL,"
                    + "due_date TEXT,"
                    + "status TEXT NOT NULL,"
                    + "FOREIGN KEY (staff_id) REFERENCES Staff(id)"
                    + ");";

            String insuranceTable = """
                    CREATE TABLE IF NOT EXISTS Insurance (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        patient_id INTEGER NOT NULL,
                        provider TEXT NOT NULL,
                        policy_number TEXT NOT NULL,
                        coverage_details TEXT,
                        coverage_percentage REAL NOT NULL,
                        FOREIGN KEY (patient_id) REFERENCES Patient(id)
                    );""";

            String billingTable = """
                    CREATE TABLE IF NOT EXISTS Billing (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        patient_id INTEGER NOT NULL,
                        description TEXT NOT NULL,
                        amount REAL NOT NULL,
                        status TEXT NOT NULL CHECK (status IN ('Pending', 'Paid')),
                        FOREIGN KEY (patient_id) REFERENCES Patient(id)
                    );""";

            String labTable = """
                    CREATE TABLE IF NOT EXISTS LaboratoryResults (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        patient_id INTEGER NOT NULL,
                        doctor_id INTEGER NOT NULL,
                        test_type TEXT NOT NULL,
                        result TEXT NOT NULL,
                        date TEXT NOT NULL,
                        FOREIGN KEY (patient_id) REFERENCES Patient(id),
                        FOREIGN KEY (doctor_id) REFERENCES Doctor(id)
                    );""";

            String referralTable = """
                    CREATE TABLE IF NOT EXISTS Referral (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        patient_id INTEGER NOT NULL,
                        referred_hospital TEXT NOT NULL,
                        reason TEXT NOT NULL,
                        report TEXT NOT NULL,
                        FOREIGN KEY (patient_id) REFERENCES Patient(id)
                    );""";

            stmt.execute(patientTable);
            stmt.execute(medicalHistoryTable);
            stmt.execute(doctorTable);
            stmt.execute(appointmentTable);
            stmt.execute(treatmentTable);
            stmt.execute(medicationTable);
            stmt.execute(staffTable);
            stmt.execute(adminTable);
            stmt.execute(prescriptionTable);
            stmt.execute(taskTable);
            stmt.execute(insuranceTable);
            stmt.execute(billingTable);
            stmt.execute(labTable);
            stmt.execute(referralTable);

            System.out.println("All tables created successfully.");

        } catch (SQLException e) {
            System.out.println("Error creating tables: " + e.getMessage());
        }
    }
}
