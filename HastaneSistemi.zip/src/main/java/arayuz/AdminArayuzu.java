package arayuz;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.util.HashMap;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import model.Doktor;
import model.Gorev;
import model.Hasta;
import model.Personel;
import model.Sevk;

public class AdminArayuzu extends JFrame {
    private JTable personelTable;
    private JTable doktorTable;
    private JTable gorevTable;
    private JTable sevkTable;

    public AdminArayuzu() {
        setTitle("Admin Yönetim Paneli");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLayout(new BorderLayout(20, 20));

        arayuzOlustur();
    }

    private void arayuzOlustur() {
        getContentPane().removeAll();
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));

        // Personel Yönetimi Tabbed Pane
        JTabbedPane personelTabbedPane = new JTabbedPane();

        personelTable = createTable(Personel.fetchAllPersonnel());
        personelTabbedPane.addTab("Personel Listesi", new JScrollPane(personelTable));
        personelTabbedPane.addTab("Yeni Personel Ekle", createYeniPersonelPanel());

        JButton personelSilButton = new JButton("Personel Sil");
        personelSilButton.addActionListener(_ -> deleteSelectedPersonel());

        contentPanel.add(personelTabbedPane);
        contentPanel.add(personelSilButton);

        // Doktor Yönetimi Tabbed Pane
        JTabbedPane doktorTabbedPane = new JTabbedPane();

        doktorTable = createTable(Doktor.fetchAllDoctors());
        doktorTabbedPane.addTab("Doktor Listesi", new JScrollPane(doktorTable));
        doktorTabbedPane.addTab("Yeni Doktor Ekle", createYeniDoktorPanel());

        JButton doktorSilButton = new JButton("Doktor Sil");
        doktorSilButton.addActionListener(_ -> deleteSelectedDoktor());

        contentPanel.add(doktorTabbedPane);
        contentPanel.add(doktorSilButton);

        // Görev Yönetimi Tabbed Pane
        JTabbedPane gorevTabbedPane = new JTabbedPane();

        gorevTable = createTable(Gorev.getAllTasks());
        gorevTabbedPane.addTab("Görev Listesi", new JScrollPane(gorevTable));
        gorevTabbedPane.addTab("Yeni Görev Ata", createYeniGorevPanel());

        JButton gorevSilButton = new JButton("Görev Sil");
        gorevSilButton.addActionListener(_ -> deleteSelectedGorev());

        contentPanel.add(gorevTabbedPane);
        contentPanel.add(gorevSilButton);

        // Hasta Sevk Yönetimi Tabbed Pane
        JTabbedPane sevkTabbedPane = new JTabbedPane();

        sevkTable = createTable(Sevk.fetchAllReferrals());
        sevkTabbedPane.addTab("Sevk Listesi", new JScrollPane(sevkTable));
        sevkTabbedPane.addTab("Yeni Sevk Ekle", createYeniSevkPanel());

        JButton sevkSilButton = new JButton("Sevk Sil");
        sevkSilButton.addActionListener(_ -> deleteSelectedSevk());

        contentPanel.add(sevkTabbedPane);
        contentPanel.add(sevkSilButton);

        JScrollPane mainScrollPane = new JScrollPane(contentPanel);
        mainScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        mainScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        add(mainScrollPane);
        revalidate();
        repaint();
    }

    private JPanel createYeniPersonelPanel() {
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel adLabel = new JLabel("Ad:");
        JTextField adField = new JTextField();

        JLabel soyadLabel = new JLabel("Soyad:");
        JTextField soyadField = new JTextField();

        JLabel pozisyonLabel = new JLabel("Pozisyon:");
        JTextField pozisyonField = new JTextField();

        JLabel kimlikLabel = new JLabel("Kimlik:");
        JTextField kimlikField = new JTextField();

        JButton ekleButton = new JButton("Personel Ekle");
        ekleButton.addActionListener(_ -> {
            String ad = adField.getText();
            String soyad = soyadField.getText();
            String pozisyon = pozisyonField.getText();
            String kimlikNo = pozisyonField.getText();

            if (ad.isEmpty() || soyad.isEmpty() || pozisyon.isEmpty() || kimlikNo.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Lütfen tüm alanları doldurun!", "Hata",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (Personel.addPersonnel(ad, soyad, pozisyon, kimlikNo)) {
                JOptionPane.showMessageDialog(panel, "Personel başarıyla eklendi!");
                arayuzOlustur();
            } else {
                JOptionPane.showMessageDialog(panel, "Personel eklenemedi!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(adLabel);
        panel.add(adField);
        panel.add(soyadLabel);
        panel.add(soyadField);
        panel.add(pozisyonLabel);
        panel.add(pozisyonField);
        panel.add(kimlikLabel);
        panel.add(kimlikField);
        panel.add(new JLabel());
        panel.add(ekleButton);

        return panel;
    }

    private JPanel createYeniDoktorPanel() {
        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel adLabel = new JLabel("Ad:");
        JTextField adField = new JTextField();

        JLabel soyadLabel = new JLabel("Soyad:");
        JTextField soyadField = new JTextField();

        JLabel uzmanlikLabel = new JLabel("Uzmanlık:");
        JTextField uzmanlikField = new JTextField();

        JLabel calismaSaatleriLabel = new JLabel("Çalışma Saatleri (HH:mm-HH:mm):");
        JTextField calismaSaatleriField = new JTextField();

        JLabel kimlikNumarasiLabel = new JLabel("Kimlik Numarası:");
        JTextField kimlikNumarasiField = new JTextField();

        JButton ekleButton = new JButton("Doktor Ekle");
        ekleButton.addActionListener(_ -> {
            String ad = adField.getText();
            String soyad = soyadField.getText();
            String uzmanlik = uzmanlikField.getText();
            String calismaSaatleri = calismaSaatleriField.getText();
            String kimlikNumarasi = kimlikNumarasiField.getText();

            if (ad.isEmpty() || soyad.isEmpty() || uzmanlik.isEmpty() || calismaSaatleri.isEmpty()
                    || kimlikNumarasi.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Lütfen tüm alanları doldurun!", "Hata",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!calismaSaatleri.matches("^\\d{2}:\\d{2}-\\d{2}:\\d{2}$")) {
                JOptionPane.showMessageDialog(panel,
                        "Lütfen çalışma saatlerini doğru formatta girin (örn: 08:00-16:00)!", "Hata",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!kimlikNumarasi.matches("\\d+")) {
                JOptionPane.showMessageDialog(panel, "Kimlik numarası sadece rakamlardan oluşmalıdır!", "Hata",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (Doktor.addDoctor(ad, soyad, uzmanlik, calismaSaatleri, kimlikNumarasi)) {
                JOptionPane.showMessageDialog(panel, "Doktor başarıyla eklendi!");
                arayuzOlustur();
            } else {
                JOptionPane.showMessageDialog(panel, "Doktor eklenemedi!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(adLabel);
        panel.add(adField);
        panel.add(soyadLabel);
        panel.add(soyadField);
        panel.add(uzmanlikLabel);
        panel.add(uzmanlikField);
        panel.add(calismaSaatleriLabel);
        panel.add(calismaSaatleriField);
        panel.add(kimlikNumarasiLabel);
        panel.add(kimlikNumarasiField);
        panel.add(new JLabel());
        panel.add(ekleButton);

        return panel;
    }

    private JTable createTable(List<?> dataList) {
        DefaultTableModel model = new DefaultTableModel();
        JTable table = new JTable(model);

        if (dataList != null && !dataList.isEmpty()) {
            Object firstElement = dataList.get(0);

            if (firstElement instanceof Personel) {
                model.setColumnIdentifiers(new String[] { "ID", "Ad", "Soyad", "Rol" });
                for (Personel personel : (List<Personel>) dataList) {
                    model.addRow(new Object[] { personel.id, personel.ad, personel.soyad, personel.rol });
                }
            } else if (firstElement instanceof Doktor) {
                model.setColumnIdentifiers(
                        new String[] { "ID", "Ad", "Soyad", "Uzmanlık", "Çalışma Saatleri", "Kimlik No" });
                for (Doktor doktor : (List<Doktor>) dataList) {
                    model.addRow(new Object[] { doktor.id, doktor.ad, doktor.soyad, doktor.uzmanlik,
                            doktor.calismaSaatleri, doktor.kimlikNumarasi });
                }
            } else if (firstElement instanceof Gorev) {
                model.setColumnIdentifiers(new String[] { "ID", "Personel Adı", "Görev Tanımı", "Son Tarih", "Durum" });
                for (Gorev gorev : (List<Gorev>) dataList) {
                    model.addRow(new Object[] { gorev.id, gorev.personel.ad + " " + gorev.personel.soyad,
                            gorev.description, gorev.dueDate, gorev.status });
                }
            } else if (firstElement instanceof Sevk) {
                model.setColumnIdentifiers(new String[] { "ID", "Hasta Adı", "Tarih", "Hedef Hastane", "Sevk Nedeni" });
                for (Sevk sevk : (List<Sevk>) dataList) {
                    model.addRow(new Object[] { sevk.id, sevk.hasta.ad + " " + sevk.hasta.soyad, sevk.sevkTarihi,
                            sevk.hedefHastane, sevk.sevkNedeni });
                }
            }
        } else {
            model.setColumnIdentifiers(new String[] { "Bilgi Bulunamadı" });
            model.addRow(new Object[] { "Kayıt bulunamadı." });
        }

        // Hide the ID column only if the table has columns
        if (model.getColumnCount() > 1) {
            table.getColumnModel().getColumn(0).setMinWidth(0);
            table.getColumnModel().getColumn(0).setMaxWidth(0);
            table.getColumnModel().getColumn(0).setWidth(0);
            table.getColumnModel().getColumn(0).setPreferredWidth(0);
        }

        return table;
    }

    private void deleteSelectedDoktor() {
        int selectedRow = doktorTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Lütfen silmek için bir doktor seçin!", "Uyarı",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int doktorId = (int) doktorTable.getModel().getValueAt(selectedRow, 0);

        int confirm = JOptionPane.showConfirmDialog(this, "Bu doktoru silmek istediğinizden emin misiniz?", "Onay",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (Doktor.deleteDoctor(doktorId)) {
                JOptionPane.showMessageDialog(this, "Doktor başarıyla silindi!");
                arayuzOlustur();
            } else {
                JOptionPane.showMessageDialog(this, "Doktor silinemedi!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void deleteSelectedGorev() {
        int selectedRow = gorevTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Lütfen silmek için bir görev seçin!", "Uyarı",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int gorevId = (int) gorevTable.getModel().getValueAt(selectedRow, 0);

        int confirm = JOptionPane.showConfirmDialog(this, "Bu görevi silmek istediğinizden emin misiniz?", "Onay",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (Gorev.deleteTask(gorevId)) {
                JOptionPane.showMessageDialog(this, "Görev başarıyla silindi!");
                arayuzOlustur();
            } else {
                JOptionPane.showMessageDialog(this, "Görev silinemedi!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private JPanel createYeniSevkPanel() {
        JPanel panel = new JPanel(new GridLayout(8, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel hastaLabel = new JLabel("Hasta Seçin:");
        JComboBox<String> hastaComboBox = new JComboBox<>();

        List<Hasta> hastaList = Hasta.fetchAllPatients();
        HashMap<String, Hasta> hastaMap = new HashMap<>();
        for (Hasta hasta : hastaList) {
            String hastaKey = hasta.ad + " " + hasta.soyad;
            hastaMap.put(hastaKey, hasta);
            hastaComboBox.addItem(hastaKey);
        }

        JLabel sevkTarihiLabel = new JLabel("Sevk Tarihi (YYYY-MM-DD):");
        JTextField sevkTarihiField = new JTextField();

        JLabel hedefHastaneLabel = new JLabel("Hedef Hastane:");
        JTextField hedefHastaneField = new JTextField();

        JLabel sevkNedeniLabel = new JLabel("Sevk Nedeni:");
        JTextField sevkNedeniField = new JTextField();

        JLabel sevkEdenDoktorLabel = new JLabel("Sevk Eden Doktor:");
        JTextField sevkEdenDoktorField = new JTextField();

        JLabel aciklamaLabel = new JLabel("Açıklama:");
        JTextArea aciklamaArea = new JTextArea(3, 20);
        JScrollPane aciklamaScrollPane = new JScrollPane(aciklamaArea);

        JButton ekleButton = new JButton("Sevk Ekle");
        ekleButton.addActionListener(_ -> {
            String hastaInfo = (String) hastaComboBox.getSelectedItem();
            String sevkTarihi = sevkTarihiField.getText();
            String hedefHastane = hedefHastaneField.getText();
            String sevkNedeni = sevkNedeniField.getText();
            String sevkEdenDoktor = sevkEdenDoktorField.getText();
            String aciklama = aciklamaArea.getText();

            if (hastaInfo == null || sevkTarihi.isEmpty() || hedefHastane.isEmpty() ||
                    sevkNedeni.isEmpty() || sevkEdenDoktor.isEmpty() || aciklama.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Lütfen tüm alanları doldurun!", "Hata",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            int hastaId = hastaMap.get(hastaInfo).id;

            if (Sevk.addReferral(hastaId, sevkTarihi, hedefHastane, sevkNedeni, sevkEdenDoktor, aciklama)) {
                JOptionPane.showMessageDialog(panel, "Sevk başarıyla eklendi!");
                sevkTarihiField.setText("");
                hedefHastaneField.setText("");
                sevkNedeniField.setText("");
                sevkEdenDoktorField.setText("");
                aciklamaArea.setText("");
                arayuzOlustur();
            } else {
                JOptionPane.showMessageDialog(panel, "Sevk eklenemedi!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(hastaLabel);
        panel.add(hastaComboBox);
        panel.add(sevkTarihiLabel);
        panel.add(sevkTarihiField);
        panel.add(hedefHastaneLabel);
        panel.add(hedefHastaneField);
        panel.add(sevkNedeniLabel);
        panel.add(sevkNedeniField);
        panel.add(sevkEdenDoktorLabel);
        panel.add(sevkEdenDoktorField);
        panel.add(aciklamaLabel);
        panel.add(aciklamaScrollPane);
        panel.add(new JLabel());
        panel.add(ekleButton);

        return panel;
    }

    private void deleteSelectedSevk() {
        int selectedRow = sevkTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Lütfen silmek için bir sevk seçin!", "Uyarı",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int sevkId = (int) sevkTable.getModel().getValueAt(selectedRow, 0);

        int confirm = JOptionPane.showConfirmDialog(this, "Bu sevki silmek istediğinizden emin misiniz?", "Onay",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (Sevk.deleteReferral(sevkId)) {
                JOptionPane.showMessageDialog(this, "Sevk başarıyla silindi!");
                arayuzOlustur();
            } else {
                JOptionPane.showMessageDialog(this, "Sevk silinemedi!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void deleteSelectedPersonel() {
        int selectedRow = personelTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Lütfen silmek için bir personel seçin!", "Uyarı",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        int personelId = (int) personelTable.getModel().getValueAt(selectedRow, 0);
        if (Personel.deletePersonnel(personelId)) {
            JOptionPane.showMessageDialog(this, "Personel başarıyla silindi!");
            arayuzOlustur();
        }
    }

    private JPanel createYeniGorevPanel() {
        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel personelLabel = new JLabel("Personel Seçin:");
        JComboBox<String> personelComboBox = new JComboBox<>();

        // Fetch personnel and store them in a HashMap
        List<Personel> personelList = Personel.fetchAllPersonnel();
        HashMap<String, Personel> personelMap = new HashMap<>();
        for (Personel personel : personelList) {
            String personelKey = personel.ad + " " + personel.soyad + " (" + personel.rol + ")";
            personelMap.put(personelKey, personel);
            personelComboBox.addItem(personelKey);
        }

        JLabel gorevTanimiLabel = new JLabel("Görev Tanımı:");
        JTextField gorevTanimiField = new JTextField();

        JLabel dueDateLabel = new JLabel("Son Tarih (YYYY-MM-DD):");
        JTextField dueDateField = new JTextField();

        JLabel statusLabel = new JLabel("Durum:");
        JComboBox<String> statusComboBox = new JComboBox<>(new String[] { "Beklemede", "Tamamlandı", "İptal Edildi" });

        JButton ekleButton = new JButton("Görev Ekle");
        ekleButton.addActionListener(_ -> {
            String personelInfo = (String) personelComboBox.getSelectedItem();
            String gorevTanimi = gorevTanimiField.getText();
            String dueDate = dueDateField.getText();
            String status = (String) statusComboBox.getSelectedItem();

            if (personelInfo == null || gorevTanimi.isEmpty() || dueDate.isEmpty() || status.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Lütfen tüm alanları doldurun!", "Hata",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            int personelId = personelMap.get(personelInfo).id;

            if (Gorev.addTask(personelId, gorevTanimi, dueDate, status)) {
                JOptionPane.showMessageDialog(panel, "Görev başarıyla eklendi!");
                gorevTanimiField.setText("");
                dueDateField.setText("");
                statusComboBox.setSelectedIndex(0);
                arayuzOlustur();
            } else {
                JOptionPane.showMessageDialog(panel, "Görev eklenemedi!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(personelLabel);
        panel.add(personelComboBox);
        panel.add(gorevTanimiLabel);
        panel.add(gorevTanimiField);
        panel.add(dueDateLabel);
        panel.add(dueDateField);
        panel.add(statusLabel);
        panel.add(statusComboBox);
        panel.add(new JLabel());
        panel.add(ekleButton);

        return panel;
    }
}
