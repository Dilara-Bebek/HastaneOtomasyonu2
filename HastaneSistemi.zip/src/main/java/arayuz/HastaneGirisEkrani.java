package arayuz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import model.Doktor;
import model.Hasta;

public class HastaneGirisEkrani extends JFrame {

    public HastaneGirisEkrani() {
        setTitle("Hastane Yönetim Sistemi - Giriş");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setBackground(new Color(46, 139, 87));
        panel.setLayout(new GridBagLayout());

        JLabel baslikLabel = new JLabel("Hastane Yönetim Sistemine Hoşgeldiniz");
        baslikLabel.setForeground(Color.WHITE);
        baslikLabel.setFont(new Font("Arial", Font.BOLD, 18));

        JLabel rolLabel = new JLabel("Giriş Türü:");
        rolLabel.setForeground(Color.WHITE);
        String[] kullaniciRolleri = { "Hasta", "Doktor", "Yönetici" };
        JComboBox<String> rolSecimi = new JComboBox<>(kullaniciRolleri);

        JLabel kullaniciLabel = new JLabel("Kimlik NO / Kullanıcı Adı:");
        kullaniciLabel.setForeground(Color.WHITE);
        JTextField kullaniciMetni = new JTextField(15);

        JLabel sifreLabel = new JLabel("Şifre:");
        sifreLabel.setForeground(Color.WHITE);
        JPasswordField sifreMetni = new JPasswordField(15);

        JButton girisButonu = new JButton("Giriş Yap");
        girisButonu.setBackground(Color.WHITE);
        girisButonu.setForeground(new Color(46, 139, 87));
        girisButonu.setFont(new Font("Arial", Font.BOLD, 14));

        girisButonu.addActionListener((ActionEvent _) -> {
            String rol = (String) rolSecimi.getSelectedItem();
            String kullaniciAdi = kullaniciMetni.getText();
            String sifre = new String(sifreMetni.getPassword());
            Integer id = girisKontrolEt(kullaniciAdi, sifre, rol);
            if (id != null) {
                dispose();
                switch (rol) {
                    case "Hasta" -> new HastaArayuzu(Hasta.getHastaFromID(id)).setVisible(true);
                    case "Doktor" -> new DoktorArayuzu(Doktor.fetchDoktorById(id)).setVisible(true);
                    case "Yönetici" -> new AdminArayuzu().setVisible(true);
                    default -> {
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Hatalı Giriş Bilgileri", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        });

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(baslikLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(rolLabel, gbc);

        gbc.gridx = 1;
        panel.add(rolSecimi, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(kullaniciLabel, gbc);

        gbc.gridx = 1;
        panel.add(kullaniciMetni, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(sifreLabel, gbc);

        gbc.gridx = 1;
        panel.add(sifreMetni, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        panel.add(girisButonu, gbc);

        add(panel, BorderLayout.CENTER);
        setLocationRelativeTo(null); // Frame'i ekranın ortasında oluşturmak için

    }

    private Integer girisKontrolEt(String kullaniciAdi, String sifre, String rol) {
        String url = "jdbc:sqlite:hospital.db";
        String tableName = null;

        switch (rol) {
            case "Hasta" -> tableName = "Patient";
            case "Doktor" -> tableName = "Doctor";
            case "Yönetici" -> tableName = "Administrator";
            default -> {
                return null;
            }
        }

        String query = null;
        if (rol.equals("Yönetici")) {
            query = "SELECT id FROM " + tableName + " WHERE username = ? AND password = ?";
        } else {
            query = "SELECT id FROM " + tableName + " WHERE identity_number = ? AND password = ?";
        }

        try (Connection conn = DriverManager.getConnection(url);
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, kullaniciAdi);
            pstmt.setString(2, sifre);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("id");
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}