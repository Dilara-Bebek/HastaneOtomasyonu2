package arayuz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import model.Doktor;
import model.Hasta;
import model.LaboratuvarSonucu;
import model.Randevu;
import model.Recete;
import model.Tedavi;

public class DoktorArayuzu extends JFrame {
    private final Doktor doktor;
    private HashMap<String, Hasta> hastaMap;
    private JTable upcomingRandevuTable;
    private JTable pastRandevuTable;
    private JTable tedaviTable;
    private JTable labResultsTable;

    public DoktorArayuzu(Doktor doktor) {
        this.doktor = doktor;
        setTitle("Doktor Yönetim Paneli");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 1000);
        setLayout(new BorderLayout(20, 20));

        arayuzOlustur();
    }

    private void arayuzOlustur() {
        getContentPane().removeAll();
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));

        // Doktor Bilgileri Paneli
        JPanel doktorBilgiPanel = new JPanel(new BorderLayout());
        doktorBilgiPanel.setBorder(BorderFactory.createTitledBorder("Doktor Bilgileri"));

        JLabel doktorAdi = new JLabel("Doktor Adı: " + doktor.ad + " " + doktor.soyad, JLabel.LEFT);
        JLabel uzmanlik = new JLabel("Uzmanlık: " + doktor.uzmanlik, JLabel.LEFT);
        JLabel calismaSaatleri = new JLabel("Çalışma Saatleri: " + doktor.calismaSaatleri, JLabel.LEFT);
        JLabel kimlikNo = new JLabel("Kimlik No: " + doktor.kimlikNumarasi, JLabel.LEFT);

        JPanel bilgiPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        bilgiPanel.add(doktorAdi);
        bilgiPanel.add(uzmanlik);
        bilgiPanel.add(calismaSaatleri);
        bilgiPanel.add(kimlikNo);

        doktorBilgiPanel.add(new JScrollPane(bilgiPanel), BorderLayout.CENTER);
        contentPanel.add(doktorBilgiPanel);

        // Randevular
        JTabbedPane randevuTabbedPane = new JTabbedPane();

        upcomingRandevuTable = createRandevuTable(getUpcomingAppointments());
        JScrollPane upcomingScrollPane = new JScrollPane(upcomingRandevuTable);
        randevuTabbedPane.addTab("Yaklaşan Randevular", upcomingScrollPane);

        pastRandevuTable = createRandevuTable(getPastAppointments());
        JScrollPane pastScrollPane = new JScrollPane(pastRandevuTable);
        randevuTabbedPane.addTab("Geçmiş Randevular", pastScrollPane);

        JButton randevuSilButon = new JButton("Randevu Sil");
        randevuSilButon.addActionListener(_ -> deleteSelectedAppointment());

        contentPanel.add(randevuTabbedPane);
        contentPanel.add(randevuSilButon);

        JTabbedPane tedaviTabbedPane = new JTabbedPane();
        tedaviTable = createTable(Tedavi.fetchTreatmentsByDoctorId(doktor.id));
        tedaviTabbedPane.addTab("Aktif Tedaviler", new JScrollPane(tedaviTable));

        // Panel for adding a new treatment
        tedaviTabbedPane.addTab("Yeni Tedavi Ekle", createYeniTedaviPanel());
        JButton tedaviSilButon = new JButton("Tedavi Sil");
        tedaviSilButon.addActionListener(_ -> deleteSelectedTedavi());

        contentPanel.add(tedaviTabbedPane);
        contentPanel.add(tedaviSilButon);

        JTabbedPane labResultsPane = new JTabbedPane();
        labResultsTable = createTable(
                LaboratuvarSonucu.fetchLaboratuvarSonucuByDoctorId(doktor.id));
        labResultsPane.addTab("Laboratuvar Sonuçları", new JScrollPane(labResultsTable));
        labResultsPane.addTab("Yeni Laboratuvar Sonucu Ekle", createLaboratuvarSonucuPanel());
        JButton labResDeleteButton = new JButton("Laboratuvar Sonucu Sil");
        labResDeleteButton.addActionListener(_ -> deleteSelectedLaboratuvarSonucu());

        contentPanel.add(labResultsPane);
        contentPanel.add(labResDeleteButton);

        JScrollPane mainScrollPane = new JScrollPane(contentPanel);
        mainScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        mainScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        add(mainScrollPane);
        revalidate();
        repaint();

    }

    private void deleteSelectedLaboratuvarSonucu() {
        int selectedRow = labResultsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Lütfen silmek için bir laboratuvar sonucu seçin!", "Uyarı",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int sonucId = (int) labResultsTable.getModel().getValueAt(selectedRow, 0);

        int confirm = JOptionPane.showConfirmDialog(this, "Bu laboratuvar sonucunu silmek istediğinizden emin misiniz?",
                "Onay", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (LaboratuvarSonucu.deleteLabResult(sonucId)) {
                JOptionPane.showMessageDialog(this, "Laboratuvar sonucu başarıyla silindi!");
                arayuzOlustur();
            } else {
                JOptionPane.showMessageDialog(this, "Laboratuvar sonucu silinemedi!", "Hata",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private JPanel createLaboratuvarSonucuPanel() {
        JPanel p = new JPanel();
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel hastaLabel = new JLabel("Hasta Seçin:");
        JComboBox<String> hastaComboBox = new JComboBox<>();

        hastaMap = new HashMap<>();
        List<Randevu> randevuList = Randevu.fetchAppointmentsByDoctorId(doktor.id);
        for (Randevu randevu : randevuList) {
            String hastaKey = randevu.hasta.ad + " " + randevu.hasta.soyad;
            hastaMap.put(hastaKey, randevu.hasta);
        }

        for (String hastaKey : hastaMap.keySet()) {
            hastaComboBox.addItem(hastaKey);
        }

        JLabel testAdiLabel = new JLabel("Test Adı:");
        JTextField testAdiField = new JTextField();

        JLabel sonucLabel = new JLabel("Sonuç:");
        JTextField sonucField = new JTextField();

        JLabel testTarihiLabel = new JLabel("Test Tarihi (YYYY-MM-DD):");
        JTextField testTarihiField = new JTextField();

        JButton kaydetButton = new JButton("Laboratuvar Sonucu Ekle");
        kaydetButton.addActionListener(_ -> {
            String hastaInfo = (String) hastaComboBox.getSelectedItem();
            String testAdi = testAdiField.getText();
            String sonuc = sonucField.getText();
            String testTarihi = testTarihiField.getText();

            if (hastaInfo == null || testAdi.isEmpty() || sonuc.isEmpty() || testTarihi.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Lütfen tüm alanları doldurun!", "Hata",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                int hastaId = hastaMap.get(hastaInfo).id;

                if (LaboratuvarSonucu.addLabResult(hastaId, doktor.id, testAdi, sonuc, testTarihi)) {
                    JOptionPane.showMessageDialog(panel, "Laboratuvar sonucu başarıyla eklendi!");
                    testAdiField.setText("");
                    sonucField.setText("");
                    testTarihiField.setText("");
                    arayuzOlustur();
                } else {
                    JOptionPane.showMessageDialog(panel, "Laboratuvar sonucu eklenemedi!", "Hata",
                            JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(panel, "Beklenmedik bir hata oluştu!", "Hata", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        });

        panel.add(hastaLabel);
        panel.add(hastaComboBox);
        panel.add(testAdiLabel);
        panel.add(testAdiField);
        panel.add(sonucLabel);
        panel.add(sonucField);
        panel.add(testTarihiLabel);
        panel.add(testTarihiField);
        panel.add(new JLabel());
        panel.add(kaydetButton);
        p.add(panel);
        return p;
    }

    private JTable createRandevuTable(List<Randevu> randevuList) {
        String[] columns = { "ID", "Hasta Adı", "Tarih", "Saat" };
        DefaultTableModel model = new DefaultTableModel(columns, 0);

        for (Randevu randevu : randevuList) {
            model.addRow(new Object[] { randevu.id, randevu.hasta.ad, randevu.tarih, randevu.zaman });
        }

        JTable table = new JTable(model);
        table.getColumnModel().getColumn(0).setMinWidth(0);
        table.getColumnModel().getColumn(0).setMaxWidth(0);
        table.getColumnModel().getColumn(0).setWidth(0);
        table.getColumnModel().getColumn(0).setPreferredWidth(0);

        customizeTableAppearance(table);
        return table;
    }

    private void deleteSelectedAppointment() {
        int selectedRow = upcomingRandevuTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Lütfen silmek için bir randevu seçin!", "Uyarı",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int randevuId = (int) upcomingRandevuTable.getModel().getValueAt(selectedRow, 0);

        int confirm = JOptionPane.showConfirmDialog(this, "Bu randevuyu silmek istediğinizden emin misiniz?", "Onay",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (Randevu.deleteAppointment(randevuId)) {
                JOptionPane.showMessageDialog(this, "Randevu başarıyla silindi!");
            } else {
                JOptionPane.showMessageDialog(this, "Randevu silinemedi!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        }
        arayuzOlustur();
    }

    private void deleteSelectedTedavi() {
        int selectedRow = tedaviTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Lütfen silmek için bir tedavi seçin!", "Uyarı",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        System.out.println(tedaviTable.getModel().getValueAt(selectedRow, 0));
        int tedaviId = (int) tedaviTable.getModel().getValueAt(selectedRow, 0);

        int confirm = JOptionPane.showConfirmDialog(this, "Bu tedaviyi silmek istediğinizden emin misiniz?", "Onay",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (Tedavi.deleteTedavi(tedaviId)) {
                JOptionPane.showMessageDialog(this, "Tedavi başarıyla silindi!");
            } else {
                JOptionPane.showMessageDialog(this, "Tedavi silinemedi!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        }
        arayuzOlustur();
    }

    private JTable createTable(List<?> dataList) {
        DefaultTableModel model = new DefaultTableModel();
        JTable table = new JTable(model);

        if (dataList != null && !dataList.isEmpty()) {
            Object firstElement = dataList.get(0);

            if (firstElement instanceof Tedavi) {
                model.setColumnIdentifiers(new String[] { "ID", "Hasta Adı", "Tedavi Adı", "Başlangıç", "Bitiş" });
                for (Tedavi tedavi : (List<Tedavi>) dataList) {
                    model.addRow(new Object[] { tedavi.id, tedavi.hasta.ad + " " + tedavi.hasta.soyad, tedavi.tedaviAdi,
                            tedavi.baslangicTarihi, tedavi.bitisTarihi });
                }
            } else if (firstElement instanceof LaboratuvarSonucu) {
                model.setColumnIdentifiers(new String[] { "ID", "Hasta Adı", "Test Adı", "Sonuç", "Tarih" });
                for (LaboratuvarSonucu sonuc : (List<LaboratuvarSonucu>) dataList) {
                    model.addRow(
                            new Object[] { sonuc.id, sonuc.hastaId, sonuc.testAdi, sonuc.sonuc, sonuc.testTarihi });
                }
            }
        } else {
            model.setColumnIdentifiers(new String[] { "Bilgi Bulunamadı" });
            model.addRow(new Object[] { "Kayıt bulunamadı." });
        }

        // Hide the ID column
        if (model.getColumnCount() > 1) {
            table.getColumnModel().getColumn(0).setMinWidth(0);
            table.getColumnModel().getColumn(0).setMaxWidth(0);
            table.getColumnModel().getColumn(0).setWidth(0);
            table.getColumnModel().getColumn(0).setPreferredWidth(0);
        }

        customizeTableAppearance(table);
        return table;
    }

    private void customizeTableAppearance(JTable table) {
        table.setRowHeight(50);
        table.setSelectionBackground(new Color(144, 238, 144));
        table.setSelectionForeground(Color.BLACK);
    }

    private List<Randevu> getUpcomingAppointments() {
        return Randevu.fetchAppointmentsByDoctorId(doktor.id)
                .stream()
                .filter(randevu -> isFutureDate(randevu.tarih))
                .toList();
    }

    private List<Randevu> getPastAppointments() {
        return Randevu.fetchAppointmentsByDoctorId(doktor.id)
                .stream()
                .filter(randevu -> !isFutureDate(randevu.tarih))
                .toList();
    }

    private JPanel createYeniTedaviPanel() {
        JPanel p = new JPanel();
        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel hastaLabel = new JLabel("Hasta Seçin:");
        JComboBox<String> hastaComboBox = new JComboBox<>();

        List<Randevu> randevuList = Randevu.fetchAppointmentsByDoctorId(doktor.id);
        hastaMap = new HashMap<>();
        for (Randevu randevu : randevuList) {
            String hastaKey = randevu.hasta.ad + " " + randevu.hasta.soyad;
            hastaMap.put(hastaKey, randevu.hasta);
        }

        for (String hastaKey : hastaMap.keySet()) {
            hastaComboBox.addItem(hastaKey);
        }

        JLabel tedaviAdiLabel = new JLabel("Tedavi Adı:");
        JTextField tedaviAdiField = new JTextField();

        JLabel aciklamaLabel = new JLabel("Açıklama:");
        JTextField aciklamaField = new JTextField();

        JLabel baslangicTarihiLabel = new JLabel("Başlangıç Tarihi (YYYY-MM-DD):");
        JTextField baslangicTarihiField = new JTextField();

        JLabel bitisTarihiLabel = new JLabel("Bitiş Tarihi (YYYY-MM-DD):");
        JTextField bitisTarihiField = new JTextField();

        JLabel maliyetLabel = new JLabel("Maliyet (TL):");
        JTextField maliyetField = new JTextField();

        JButton kaydetButton = new JButton("Tedavi Ekle");
        kaydetButton.addActionListener(_ -> {
            String hastaInfo = (String) hastaComboBox.getSelectedItem();
            String tedaviAdi = tedaviAdiField.getText();
            String aciklama = aciklamaField.getText();
            String baslangicTarihi = baslangicTarihiField.getText();
            String bitisTarihi = bitisTarihiField.getText();
            String maliyetStr = maliyetField.getText();

            if (hastaInfo == null || tedaviAdi.isEmpty() || aciklama.isEmpty() || baslangicTarihi.isEmpty()
                    || bitisTarihi.isEmpty() || maliyetStr.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Lütfen tüm alanları doldurun!", "Hata",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                int hastaId = hastaMap.get(hastaInfo).id;
                double maliyet = Double.parseDouble(maliyetStr);

                if (Tedavi.addTreatment(hastaId, doktor.id, tedaviAdi, aciklama, baslangicTarihi, bitisTarihi,
                        maliyet)) {
                    JOptionPane.showMessageDialog(panel, "Tedavi başarıyla eklendi!");
                    tedaviAdiField.setText("");
                    aciklamaField.setText("");
                    baslangicTarihiField.setText("");
                    bitisTarihiField.setText("");
                    maliyetField.setText("");
                } else {
                    JOptionPane.showMessageDialog(panel, "Tedavi eklenemedi!", "Hata", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(panel, "Geçerli bir maliyet girin!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(hastaLabel);
        panel.add(hastaComboBox);
        panel.add(tedaviAdiLabel);
        panel.add(tedaviAdiField);
        panel.add(aciklamaLabel);
        panel.add(aciklamaField);
        panel.add(baslangicTarihiLabel);
        panel.add(baslangicTarihiField);
        panel.add(bitisTarihiLabel);
        panel.add(bitisTarihiField);
        panel.add(maliyetLabel);
        panel.add(maliyetField);
        p.add(panel);
        p.add(kaydetButton);
        return p;
    }

    private JPanel createYeniRecetePanel() {
        JPanel p = new JPanel();
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel hastaLabel = new JLabel("Hasta Seçin:");
        JComboBox<String> hastaComboBox = new JComboBox<>();

        // Create a HashMap to store unique patient names mapped to their objects
        hastaMap = new HashMap<>();
        List<Randevu> randevuList = Randevu.fetchAppointmentsByDoctorId(doktor.id);
        for (Randevu randevu : randevuList) {
            String hastaKey = randevu.hasta.ad + " " + randevu.hasta.soyad;
            hastaMap.put(hastaKey, randevu.hasta);
        }

        for (String hastaKey : hastaMap.keySet()) {
            hastaComboBox.addItem(hastaKey);
        }

        JLabel ilacAdiLabel = new JLabel("İlaç Adı:");
        JTextField ilacAdiField = new JTextField();

        JLabel dozajLabel = new JLabel("Dozaj:");
        JTextField dozajField = new JTextField();

        JLabel maliyetLabel = new JLabel("Maliyet (TL):");
        JTextField maliyetField = new JTextField();

        JButton kaydetButton = new JButton("Reçete Ekle");
        kaydetButton.addActionListener(_ -> {
            String hastaInfo = (String) hastaComboBox.getSelectedItem();
            String ilacAdi = ilacAdiField.getText();
            String dozaj = dozajField.getText();
            String maliyetStr = maliyetField.getText();

            if (hastaInfo == null || ilacAdi.isEmpty() || dozaj.isEmpty() || maliyetStr.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Lütfen tüm alanları doldurun!", "Hata",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                int hastaId = hastaMap.get(hastaInfo).id;
                double maliyet = Double.parseDouble(maliyetStr);

                if (Recete.addRecete(hastaId, doktor.id, ilacAdi, dozaj, maliyet)) {
                    JOptionPane.showMessageDialog(panel, "Reçete başarıyla eklendi!");
                    ilacAdiField.setText("");
                    dozajField.setText("");
                    maliyetField.setText("");
                } else {
                    JOptionPane.showMessageDialog(panel, "Reçete eklenemedi!", "Hata", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(panel, "Lütfen geçerli bir maliyet girin!", "Hata",
                        JOptionPane.ERROR_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(panel, "Beklenmedik bir hata oluştu!", "Hata", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        });

        panel.add(hastaLabel);
        panel.add(hastaComboBox);
        panel.add(ilacAdiLabel);
        panel.add(ilacAdiField);
        panel.add(dozajLabel);
        panel.add(dozajField);
        panel.add(maliyetLabel);
        panel.add(maliyetField);
        p.add(panel);
        p.add(kaydetButton);
        return p;
    }

    private boolean isFutureDate(String dateStr) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date appointmentDate = dateFormat.parse(dateStr);
            Calendar today = Calendar.getInstance();
            today.set(Calendar.HOUR_OF_DAY, 0);
            today.set(Calendar.MINUTE, 0);
            today.set(Calendar.SECOND, 0);
            today.set(Calendar.MILLISECOND, 0);
            return appointmentDate.after(today.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
    }
}
