package arayuz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import model.Doktor;
import model.Hasta;
import model.LaboratuvarSonucu;
import model.Randevu;
import model.Sigorta;
import model.Tedavi;

public class HastaArayuzu extends JFrame {
    private final Hasta hasta;
    private HashMap<String, Doktor> doktorMap;
    private JTable upcomingRandevuTable;
    private JTable pastRandevuTable;
    private JTable tedaviTable;
    private JTable sigortaTable;
    private JTable labResultsTable;

    public HastaArayuzu(Hasta hasta) {
        this.hasta = hasta;
        setTitle("Hasta Yönetim Paneli");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 1000);
        setLayout(new BorderLayout(20, 20));

        setExtendedState(JFrame.MAXIMIZED_BOTH);

        arayuzOlustur();
    }

    private void arayuzOlustur() {
        getContentPane().removeAll();
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));

        // Hasta Bilgileri
        JPanel hastaBilgiPanel = new JPanel(new BorderLayout());
        hastaBilgiPanel.setBorder(BorderFactory.createTitledBorder("Hasta Bilgileri"));

        JLabel hastaAdi = new JLabel("Hasta Adı: " + hasta.ad + " " + hasta.soyad);
        JLabel hastaNo = new JLabel("Kimlik No: " + hasta.kimlikNo);
        JLabel yas = new JLabel("Yaş: " + hasta.yas);
        JLabel adres = new JLabel("Adres: " + hasta.adres);

        JPanel bilgiPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        bilgiPanel.add(hastaAdi);
        bilgiPanel.add(hastaNo);
        bilgiPanel.add(yas);
        bilgiPanel.add(adres);

        hastaBilgiPanel.add(new JScrollPane(bilgiPanel), BorderLayout.CENTER);
        contentPanel.add(hastaBilgiPanel);

        // Randevular
        JTabbedPane randevuTabbedPane = new JTabbedPane();
        upcomingRandevuTable = createRandevuTable(getUpcomingAppointments());
        pastRandevuTable = createRandevuTable(getPastAppointments());

        randevuTabbedPane.addTab("Yaklaşan Randevular", new JScrollPane(upcomingRandevuTable));
        randevuTabbedPane.addTab("Yeni Randevu Al", createYeniRandevuPanel());
        randevuTabbedPane.addTab("Geçmiş Randevular", new JScrollPane(pastRandevuTable));

        JButton randevuSilButon = new JButton("Randevu Sil");
        randevuSilButon.addActionListener(_ -> deleteSelectedAppointment());

        contentPanel.add(randevuTabbedPane);
        contentPanel.add(randevuSilButon);

        // Tedavi Bilgileri
        tedaviTable = createTable(Tedavi.fetchTreatmentsByPatientId(hasta.id));

        contentPanel.add(new JScrollPane(tedaviTable));

        // Sigorta Bilgileri
        JTabbedPane sigortaTabbedPane = new JTabbedPane();
        sigortaTable = createTable(Sigorta.fetchSigortaByPatientId(hasta.id));
        JButton sigortaSilButon = new JButton("Sigorta Sil");
        sigortaSilButon.addActionListener(_ -> deleteSelectedInsurance());

        sigortaTabbedPane.addTab("Sigortalar", new JScrollPane(sigortaTable));
        sigortaTabbedPane.addTab("Yeni Sigorta Ekle", createYeniSigortaPanel());

        contentPanel.add(sigortaTabbedPane);
        contentPanel.add(sigortaSilButon);

        // Lab Results
        labResultsTable = createTable(LaboratuvarSonucu.fetchLaboratuvarSonucuByPatientId(hasta.id));
        contentPanel.add(new JScrollPane(labResultsTable));

        JScrollPane mainScrollPane = new JScrollPane(contentPanel);
        mainScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        add(mainScrollPane);
        revalidate();
        repaint();
    }

    private void deleteSelectedAppointment() {
        int selectedRow = upcomingRandevuTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Lütfen silmek için bir randevu seçin!", "Uyarı",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        int randevuId = (int) upcomingRandevuTable.getModel().getValueAt(selectedRow, 0);

        if (JOptionPane.showConfirmDialog(this, "Bu randevuyu silmek istediğinizden emin misiniz?", "Onay",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (Randevu.deleteAppointment(randevuId)) {
                JOptionPane.showMessageDialog(this, "Randevu başarıyla silindi!");
            } else {
                JOptionPane.showMessageDialog(this, "Randevu silinemedi!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        }
        arayuzOlustur();
    }

    private void deleteSelectedInsurance() {
        int selectedRow = sigortaTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Lütfen silmek için bir sigorta seçin!", "Uyarı",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        int sigortaId = (int) sigortaTable.getModel().getValueAt(selectedRow, 0);
        Sigorta.deleteSigorta(sigortaId);
        arayuzOlustur();
    }

    private JPanel createYeniRandevuPanel() {
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Fetch doctors and store them in a HashMap
        List<Doktor> doctorList = Doktor.fetchAllDoctors();
        doktorMap = new HashMap<>();
        for (Doktor doc : doctorList) {
            doktorMap.put(doc.uzmanlik + " - " + doc.ad + " " + doc.soyad, doc);
        }

        JLabel doktorLabel = new JLabel("Doktor Seçin:");
        JComboBox<String> doktorComboBox = new JComboBox<>(doktorMap.keySet().toArray(new String[0]));

        JLabel tarihLabel = new JLabel("Tarih Seçin (YYYY-MM-DD):");
        JTextField tarihField = new JTextField();

        JLabel saatLabel = new JLabel("Saat Seçin:");
        JComboBox<String> saatComboBox = new JComboBox<>();

        doktorComboBox.addActionListener(_ -> {
            String selectedDoctorName = (String) doktorComboBox.getSelectedItem();
            Doktor selectedDoctor = doktorMap.get(selectedDoctorName);

            if (selectedDoctor != null) {
                saatComboBox.removeAllItems();
                populateTimeSlots(selectedDoctor, saatComboBox);
            }
        });

        // Populate available slots for the initially selected doctor
        doktorComboBox.setSelectedIndex(0);
        populateTimeSlots(doktorMap.get(doktorComboBox.getSelectedItem()), saatComboBox);

        JButton kaydetButton = new JButton("Randevu Kaydet");
        kaydetButton.addActionListener(_ -> {
            String doktorName = (String) doktorComboBox.getSelectedItem();
            Doktor selectedDoctor = doktorMap.get(doktorName);
            String tarih = tarihField.getText();
            String saat = (String) saatComboBox.getSelectedItem();

            if (tarih.isEmpty() || saat == null) {
                JOptionPane.showMessageDialog(panel, "Lütfen tüm alanları doldurun!", "Hata",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Check if doctor is available before adding appointment
            if (Doktor.isDoctorAvailable(selectedDoctor.id, tarih, saat)) {
                if (Randevu.addAppointment(hasta.id, selectedDoctor.id, tarih, saat)) {
                    JOptionPane.showMessageDialog(panel,
                            "Randevu kaydedildi:\nDoktor: " + doktorName + "\nTarih: " + tarih + "\nSaat: " + saat);
                    arayuzOlustur();
                } else {
                    JOptionPane.showMessageDialog(panel, "Randevu kaydedilemedi!", "Hata", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(panel, "Seçilen doktor bu saatte meşgul!", "Hata",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(doktorLabel);
        panel.add(doktorComboBox);
        panel.add(tarihLabel);
        panel.add(tarihField);
        panel.add(saatLabel);
        panel.add(saatComboBox);
        panel.add(new JLabel());
        panel.add(kaydetButton);

        return panel;
    }

    private JPanel createYeniSigortaPanel() {
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel saglayiciLabel = new JLabel("Sigorta Sağlayıcısı:");
        JTextField saglayiciField = new JTextField();

        JLabel poliçeNumarasiLabel = new JLabel("Poliçe Numarası:");
        JTextField poliçeNumarasiField = new JTextField();

        JLabel kapsamDetaylariLabel = new JLabel("Kapsam Detayları:");
        JTextArea kapsamDetaylariField = new JTextArea(3, 20);
        JScrollPane kapsamScrollPane = new JScrollPane(kapsamDetaylariField);

        JLabel kapsamOraniLabel = new JLabel("Kapsam Oranı (%):");
        JTextField kapsamOraniField = new JTextField();

        JButton kaydetButton = new JButton("Sigorta Bilgilerini Kaydet");
        kaydetButton.addActionListener(_ -> {
            String saglayici = saglayiciField.getText();
            String poliçeNumarasi = poliçeNumarasiField.getText();
            String kapsamDetaylari = kapsamDetaylariField.getText();
            String kapsamOraniStr = kapsamOraniField.getText();

            if (saglayici.isEmpty() || poliçeNumarasi.isEmpty() || kapsamDetaylari.isEmpty()
                    || kapsamOraniStr.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Lütfen tüm alanları doldurun!", "Hata",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                double kapsamOrani = Double.parseDouble(kapsamOraniStr);
                if (kapsamOrani < 0 || kapsamOrani > 100) {
                    JOptionPane.showMessageDialog(panel, "Kapsam oranı 0-100 arasında olmalıdır!", "Hata",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }

                boolean success = Sigorta.addSigorta(hasta.id, saglayici, poliçeNumarasi, kapsamDetaylari, kapsamOrani);
                if (success) {
                    JOptionPane.showMessageDialog(panel, "Sigorta bilgileri başarıyla kaydedildi!");
                    saglayiciField.setText("");
                    poliçeNumarasiField.setText("");
                    kapsamDetaylariField.setText("");
                    kapsamOraniField.setText("");
                    arayuzOlustur();
                } else {
                    JOptionPane.showMessageDialog(panel, "Sigorta bilgileri kaydedilemedi!", "Hata",
                            JOptionPane.ERROR_MESSAGE);
                }

            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(panel, "Lütfen geçerli bir yüzde girin!", "Hata",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(saglayiciLabel);
        panel.add(saglayiciField);
        panel.add(poliçeNumarasiLabel);
        panel.add(poliçeNumarasiField);
        panel.add(kapsamDetaylariLabel);
        panel.add(kapsamScrollPane);
        panel.add(kapsamOraniLabel);
        panel.add(kapsamOraniField);
        panel.add(new JLabel());
        panel.add(kaydetButton);

        return panel;
    }

    // 30'ar dakikalık şekilde zaman dropboxunu doldurmak için
    private void populateTimeSlots(Doktor doctor, JComboBox<String> saatComboBox) {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        try {
            Date startTime = sdf.parse(doctor.calismaSaatleri.split("-")[0]);
            Date endTime = sdf.parse(doctor.calismaSaatleri.split("-")[1]);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(startTime);

            while (calendar.getTime().before(endTime) || calendar.getTime().equals(endTime)) {
                saatComboBox.addItem(sdf.format(calendar.getTime()));
                calendar.add(Calendar.MINUTE, 30);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private JTable createRandevuTable(List<Randevu> randevuList) {
        String[] columns = { "Doktor", "Tarih", "Saat" };
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        for (Randevu randevu : randevuList) {
            model.addRow(new Object[] { randevu.doktor.ad, randevu.tarih, randevu.zaman });
        }
        JTable table = new JTable(model);
        customizeTableAppearance(table);
        return table;
    }

    private JTable createTable(List<?> dataList) {
        DefaultTableModel model = new DefaultTableModel();
        JTable table = new JTable(model);

        if (dataList != null && !dataList.isEmpty()) {
            Object firstElement = dataList.get(0);
            if (firstElement instanceof Tedavi) {
                model.setColumnIdentifiers(new String[] { "ID", "Tedavi Adı", "Başlangıç", "Bitiş", "Maliyet" });
                for (Tedavi tedavi : (List<Tedavi>) dataList) {
                    model.addRow(new Object[] { tedavi.id, tedavi.tedaviAdi, tedavi.baslangicTarihi, tedavi.bitisTarihi,
                            tedavi.maliyet });
                }
            } else if (firstElement instanceof Sigorta) {
                model.setColumnIdentifiers(new String[] { "ID", "Sağlayıcı", "Poliçe", "Kapsam" });
                for (Sigorta sigorta : (List<Sigorta>) dataList) {
                    model.addRow(new Object[] { sigorta.id, sigorta.saglayici, sigorta.policeNumarasi,
                            sigorta.kapsamYuzdesi });
                }
            }
        } else {
            model.setColumnIdentifiers(new String[] { "Bilgi Bulunamadı" });
            model.addRow(new Object[] { "Kayıt bulunamadı." });
        }

        if (table.getModel().getColumnCount() > 1) {
            hideIdColumn(table);
        }
        customizeTableAppearance(table);
        return table;
    }

    private void hideIdColumn(JTable table) {
        table.getColumnModel().getColumn(0).setMinWidth(0);
        table.getColumnModel().getColumn(0).setMaxWidth(0);
        table.getColumnModel().getColumn(0).setWidth(0);
        table.getColumnModel().getColumn(0).setPreferredWidth(0);
    }

    private void customizeTableAppearance(JTable table) {
        table.setRowHeight(50);
        table.setSelectionBackground(new Color(144, 238, 144));
        table.setSelectionForeground(Color.BLACK);
    }

    // Helper methods to get upcoming and past appointments
    private List<Randevu> getUpcomingAppointments() {
        return Randevu.fetchAppointmentsByPatientId(hasta.id)
                .stream()
                .filter(randevu -> isFutureDate(randevu.tarih))
                .toList();
    }

    private List<Randevu> getPastAppointments() {
        return Randevu.fetchAppointmentsByPatientId(hasta.id)
                .stream()
                .filter(randevu -> !isFutureDate(randevu.tarih))
                .toList();
    }

    private boolean isFutureDate(String dateStr) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date appointmentDate = dateFormat.parse(dateStr);

            // Get current date without time component
            Calendar today = Calendar.getInstance();
            today.set(Calendar.HOUR_OF_DAY, 0);
            today.set(Calendar.MINUTE, 0);
            today.set(Calendar.SECOND, 0);
            today.set(Calendar.MILLISECOND, 0);

            // Compare normalized dates
            return appointmentDate.after(today.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
    }

}
