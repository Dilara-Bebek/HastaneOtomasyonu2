import javax.swing.SwingUtilities;

import arayuz.HastaneGirisEkrani;

public class HastaneSistemi {

    public static void main(String[] args) {
        Database.tableOlustur();
        DataOlustur.veriEkle();

        SwingUtilities.invokeLater(() -> {
            HastaneGirisEkrani hge = new HastaneGirisEkrani();
            hge.setVisible(true);
        });
    }
}
