import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DataOlustur {
    private static final String URL = "jdbc:sqlite:hospital.db";

    public static void veriEkle() {
        try (Connection conn = DriverManager.getConnection(URL)) {
            String patientQuery = "INSERT INTO Patient (name, surname, age, identity_number, address, password) VALUES (?, ?, ?, ?, ?, ?)";
            String medicalHistoryQuery = "INSERT INTO MedicalHistory (patient_id, description, date) VALUES (?, ?, ?)";
            String doctorQuery = "INSERT INTO Doctor (name, surname, specialty, work_hours, identity_number, password) VALUES (?, ?, ?, ?, ?, ?)";
            String adminQuery = "INSERT INTO Administrator (name, surname, username, password) VALUES (?, ?, ?, ?)";
            String appointmentQuery = "INSERT INTO Appointment (patient_id, doctor_id, date, time) VALUES (?, ?, ?, ?)";
            String treatmentQuery = "INSERT INTO Treatment (patient_id, doctor_id, treatment_name, description, start_date, end_date, cost) VALUES (?, ?, ?, ?, ?, ?, ?)";
            String medicationQuery = "INSERT INTO Medication (medication_name, stock) VALUES (?, ?)";
            String staffQuery = "INSERT INTO Staff (name, surname, role, identity_number) VALUES (?, ?, ?, ?)";
            String prescriptionQuery = "INSERT INTO Prescription (patient_id, doctor_id, medication_name, dosage) VALUES (?, ?, ?, ?)";
            String taskQuery = "INSERT INTO Task (staff_id, description, due_date, status) VALUES (?, ?, ?, ?)";

            try (
                    PreparedStatement patientStmt = conn.prepareStatement(patientQuery);
                    PreparedStatement medicalHistoryStmt = conn.prepareStatement(medicalHistoryQuery);
                    PreparedStatement doctorStmt = conn.prepareStatement(doctorQuery);
                    PreparedStatement adminStmt = conn.prepareStatement(adminQuery);
                    PreparedStatement appointmentStmt = conn.prepareStatement(appointmentQuery);
                    PreparedStatement treatmentStmt = conn.prepareStatement(treatmentQuery);
                    PreparedStatement medicationStmt = conn.prepareStatement(medicationQuery);
                    PreparedStatement staffStmt = conn.prepareStatement(staffQuery);
                    PreparedStatement prescriptionStmt = conn.prepareStatement(prescriptionQuery);
                    PreparedStatement taskStmt = conn.prepareStatement(taskQuery)) {
                // Adding patients
                patientStmt.setString(1, "Hasta1");
                patientStmt.setString(2, "Soyad1");
                patientStmt.setInt(3, 30);
                patientStmt.setString(4, "123456");
                patientStmt.setString(5, "Adres1");
                patientStmt.setString(6, "123123");
                patientStmt.executeUpdate();

                patientStmt.setString(1, "Hasta2");
                patientStmt.setString(2, "Soyad2");
                patientStmt.setInt(3, 40);
                patientStmt.setString(4, "123457");
                patientStmt.setString(5, "Adres2");
                patientStmt.setString(6, "123123");
                patientStmt.executeUpdate();

                // Adding medical history
                medicalHistoryStmt.setInt(1, 1);
                medicalHistoryStmt.setString(2, "Hipertansiyon");
                medicalHistoryStmt.setString(3, "2023-05-10");
                medicalHistoryStmt.executeUpdate();

                medicalHistoryStmt.setInt(1, 2);
                medicalHistoryStmt.setString(2, "Diyabet");
                medicalHistoryStmt.setString(3, "2022-11-15");
                medicalHistoryStmt.executeUpdate();

                // Adding doctors
                doctorStmt.setString(1, "Doktor1");
                doctorStmt.setString(2, "Soyad1");
                doctorStmt.setString(3, "Kardiyoloji");
                doctorStmt.setString(4, "09:00-17:00");
                doctorStmt.setString(5, "223456");
                doctorStmt.setString(6, "123123");
                doctorStmt.executeUpdate();

                doctorStmt.setString(1, "Doktor2");
                doctorStmt.setString(2, "Soyad2");
                doctorStmt.setString(3, "Dahiliye");
                doctorStmt.setString(4, "10:00-18:00");
                doctorStmt.setString(5, "223457");
                doctorStmt.setString(6, "123123");
                doctorStmt.executeUpdate();

                // Adding admin
                adminStmt.setString(1, "Admin1");
                adminStmt.setString(2, "Soyad1");
                adminStmt.setString(3, "admin1");
                adminStmt.setString(4, "123123");
                adminStmt.executeUpdate();

                // Adding appointments
                appointmentStmt.setInt(1, 1);
                appointmentStmt.setInt(2, 1);
                appointmentStmt.setString(3, "2024-03-15");
                appointmentStmt.setString(4, "14:30");
                appointmentStmt.executeUpdate();

                appointmentStmt.setInt(1, 1);
                appointmentStmt.setInt(2, 1);
                appointmentStmt.setString(3, "2025-03-15");
                appointmentStmt.setString(4, "14:30");
                appointmentStmt.executeUpdate();

                appointmentStmt.setInt(1, 2);
                appointmentStmt.setInt(2, 2);
                appointmentStmt.setString(3, "2024-03-20");
                appointmentStmt.setString(4, "10:15");
                appointmentStmt.executeUpdate();

                // Adding treatments
                treatmentStmt.setInt(1, 1);
                treatmentStmt.setInt(2, 1);
                treatmentStmt.setString(3, "Fizik Tedavi");
                treatmentStmt.setString(4, "Bel ağrısı için fizyoterapi");
                treatmentStmt.setString(5, "2024-01-10");
                treatmentStmt.setString(6, "2024-02-10");
                treatmentStmt.setDouble(7, 200);
                treatmentStmt.executeUpdate();

                // Adding medications
                medicationStmt.setString(1, "Aspirin");
                medicationStmt.setInt(2, 50);
                medicationStmt.executeUpdate();

                medicationStmt.setString(1, "Parol");
                medicationStmt.setInt(2, 30);
                medicationStmt.executeUpdate();

                // Adding staff
                staffStmt.setString(1, "Hemşire1");
                staffStmt.setString(2, "Soyad1");
                staffStmt.setString(3, "Hemşire");
                staffStmt.setString(4, "333456");
                staffStmt.executeUpdate();

                // Adding prescriptions
                prescriptionStmt.setInt(1, 1);
                prescriptionStmt.setInt(2, 1);
                prescriptionStmt.setString(3, "Aspirin");
                prescriptionStmt.setString(4, "1x1");
                prescriptionStmt.executeUpdate();

                // Adding tasks
                taskStmt.setInt(1, 1);
                taskStmt.setString(2, "Günlük hasta kontrolleri");
                taskStmt.setString(3, "2024-03-01");
                taskStmt.setString(4, "Tamamlanmadı");
                taskStmt.executeUpdate();

                System.out.println("Test verileri başarıyla eklendi.");
            }
        } catch (SQLException e) {
            System.out.println("Veri ekleme hatası: " + e.getMessage());
        }
    }
}
